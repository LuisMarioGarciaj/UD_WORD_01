using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;

public class MovablePlataform : MonoBehaviour
{
    [SerializeField]
    private Transform[] movementPoints;
    [SerializeField]
    private float moveSpeed;
    private int nextPlataform = 1;
    private bool plataformOrder = true;

  
    // Update is called once per frame
    void Update()
    {
        if(plataformOrder && nextPlataform +1 >= movementPoints.Length){
            plataformOrder = false;
        }
        if(!plataformOrder && nextPlataform  <= 0){
            plataformOrder = true;
        }
        if(Vector2.Distance(transform.position, movementPoints[nextPlataform].position) < 0.1f){
    
            if(plataformOrder){
                nextPlataform += 1;
            }else{
                nextPlataform -= 1;    
            }
    
        }

        //plaraforma se mueva
        transform.position = Vector2.MoveTowards(transform.position,movementPoints[nextPlataform].position,
        moveSpeed*Time.deltaTime);
    }
    private void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.CompareTag("Player")){
            other.transform.SetParent(this.transform);
        }
    }
    private void OnCollisionExit2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            other.transform.SetParent(null);
        }
    }
}
