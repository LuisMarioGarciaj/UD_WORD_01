using System.Collections;   
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [Header("Estadisticas")]

    public float runSpeed = 10f;
    public float jumpForce = 20f;
    public bool canJump = true;
    int randomRight_Key;
    int randomLeft_Key;
    int ramdomJump_Key;

    [Header("Referencias")]
    public Rigidbody2D rb;
    //public Animator animator;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Movement();
        Jump();
       // Mirror();
    }
    void Movement()
    {                               //eje x * velocidad
        rb.velocity = new Vector2(Input.GetAxis("Horizontal") * runSpeed, rb.velocity.y);
      //  animator.SetFloat("Speed", Mathf.Abs(rb.velocity.y));
    }
    void Jump()
    {
        if (canJump) {
            if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W))
            {
                rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
                canJump = false;

            }
        }
    }
    void Mirror()
    {
        if (rb.velocity.x < 0)
        {
            transform.rotation = Quaternion.Euler(0, 180, 0);
        }
        else if (rb.velocity.x > 0)
        {
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
    }
}
